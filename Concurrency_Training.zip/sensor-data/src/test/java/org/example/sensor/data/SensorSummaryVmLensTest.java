package org.example.sensor.data;

import static org.junit.Assert.assertEquals;

import java.time.Instant;

import org.example.sensor.data.SensorData.SensorType;
import org.junit.Test;

import com.vmlens.api.AllInterleavings;

public class SensorSummaryVmLensTest {
	
	SensorSummary sum = new SensorSummary();

	@Test
	public void testSummaryDataAfterCreation() throws InterruptedException {
		try (AllInterleavings allInterleavings = new AllInterleavings("sensorSummaryData.test")) {
			while (allInterleavings.hasNext()) {
				Instant now = Instant.now();
				sum.addSensorData(new SensorData(SensorType.PRESSURE, now, 21.0, "1001"));
				sum.setTimeStamp(now);
				Thread first = new Thread(() -> {
//					sum.setNumberOfSensors(4);
					sum.addSensorData(new SensorData(SensorType.TEMPERATURE, now, 71.0, "2001"));
				});
				Thread second = new Thread(() -> {
//					sum.setNumberOfSensors(2);
					sum.addSensorData(new SensorData(SensorType.VOLUME, now, 21.0, "3001"));
				});
				first.start();
				second.start();

				first.join();
				second.join();

				assertEquals(3, sum.getNumberOfSensors());

			}
		}
	}
	
}
