package org.example.sensor.data;

import static org.junit.Assert.assertEquals;

import java.time.Instant;

import org.example.sensor.data.SensorData.SensorType;
import org.junit.Test;

import com.vmlens.api.AllInterleavings;

public class SensorDataVmLensTest {
	
	SensorData sensorData = new SensorData(SensorType.TEMPERATURE, Instant.now(), 72.0, "TEMP001");

	@Test
	public void test() throws InterruptedException {
		try (AllInterleavings allInterleavings = new AllInterleavings("sensordata.test")) {
			while (allInterleavings.hasNext()) {
				sensorData = new SensorData(SensorType.TEMPERATURE, Instant.now(), 72.0, "TEMP001");
				Thread first = new Thread(() -> {
					sensorData.getSensorType();
				});
				Thread second = new Thread(() -> {
					sensorData.getSensorType();
				});
				first.start();
				second.start();

				first.join();
				second.join();

				assertEquals(SensorType.TEMPERATURE, sensorData.getSensorType());

			}
		}
	}

}
