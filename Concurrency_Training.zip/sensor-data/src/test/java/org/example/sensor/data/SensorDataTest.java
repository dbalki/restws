package org.example.sensor.data;

import static org.junit.Assert.*;

import java.time.Instant;

import org.example.sensor.data.SensorData.SensorType;
import org.junit.Test;

public class SensorDataTest {

	@Test
	public void testSensorData() {
		Instant now = Instant.now();
		SensorData sensorData = new SensorData(SensorType.TEMPERATURE, now, 10.0, "1");
		assertEquals(SensorType.TEMPERATURE, sensorData.getSensorType());
		assertEquals(now, sensorData.getTimeStamp());
		assertEquals(10.0, sensorData.getData(), 0.0);
		assertEquals("1", sensorData.getId());
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void shouldThrowIllegalArgExceptionIfTimeStampNull() {
		new SensorData(SensorType.TEMPERATURE, null, 10.0, "1");
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void shouldThrowIllegalArgExceptionIfIdNull() {
		new SensorData(SensorType.TEMPERATURE, Instant.now(), 10.0, null);
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void shouldThrowIllegalArgExceptionIfIdEmpty() {
		new SensorData(SensorType.TEMPERATURE, Instant.now(), 10.0, "");
	}
}
