package org.example.sensor.data;

import static org.junit.Assert.assertEquals;

import java.time.Instant;
import java.util.Queue;

import org.example.sensor.data.SensorData.SensorType;
import org.junit.Test;

public class SensorSummaryTest {

	@Test
	public void testSummaryDataAfterCreation() {
		SensorSummary sum = new SensorSummary();
		Instant now = Instant.now();
		sum.addSensorData(new SensorData(SensorType.PRESSURE, now, 21.0, "1001"));
		sum.setTimeStamp(now);
		assertEquals(now, sum.getTimeStamp());
		sum.setNumberOfSensors(2);
		assertEquals(2, sum.getNumberOfSensors());
		Queue<SensorData> sensorDataQueue = sum.getSensorDataQueue();
		assertEquals(1, sensorDataQueue.size());
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void shouldThrowIllegalArgExceptionIfTimeStampNull() {
		SensorSummary sum = new SensorSummary();
		sum.setTimeStamp(null);
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void shouldThrowIllegalArgExceptionIfNumberOfSensorIsLt0() {
		SensorSummary sum = new SensorSummary();
		sum.setTimeStamp(Instant.now());
		sum.setNumberOfSensors(-1);
	}
}
