/**
 * 
 */
package org.example.sensor;

import java.time.Instant;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.sensor.data.SensorData;
import org.example.sensor.data.SensorData.SensorType;
import org.example.sensor.simulator.SensorSimulator;

/**
 * @author Administrator
 * Temperature sensor that senses the temperature and push the data to reporter.
 * @ThreadSafe
 */
public class SensorImpl implements Sensor {

	private static final Logger log = LogManager.getLogger();
	private static final int INTERVAL = 3000; 
	
	private SensorStatus status;
	private SensorReporter recorder;
	private SensorSimulator simulator;
	private SensorData sensorData;
	private double sensorValue;
	
	private Worker worker;
	private Thread runner;
	private ReentrantLock lock;
	
	/**
	 * The default constructor for the <strong>sequential</strong> SensorImpl.
	 * <br>
	 * <br>
	 * The initial values are:
	 * <ul>
	 *   <li>SensorStatus: <strong>INITIALIZED</strong></li>
	 *   <li>sensorData: 
	 *     <ul>
	 *       <li>SensorType: <strong>a random SensorType</strong></li>
	 *       <li>Value: <strong>a random double</strong></li>
	 *       <li>TimeStamp: <strong>Current Instant</strong></li>
	 *       <li>SensorId: <strong>SensorType concatenated w/ 3 random uppercase letters</strong></li>
	 *     </ul>
	 *   </li>
	 * </ul>
	 * 
	 * @param simulator the SensorSimulator to use as a data generator
	 * @throws InterruptedException 
	 * @throws IllegalArgumentException is the simulator is null
	 */
	public SensorImpl(final SensorSimulator simulator) throws InterruptedException {
		log.debug("constructing SensorImpl");
		if (simulator == null)
		{
			log.error("the SensorSimulator is null");
			throw new IllegalArgumentException("SensorSimulator cannot be null");
		}
		worker = new Worker();
		this.lock = new ReentrantLock();
		this.simulator = simulator;
		initializeSensorData();
		setStatus(SensorStatus.INITIALIZED);
	}

	private void initializeSensorData()
	{
		log.debug("initializing SersorData");
		final int max = 3;
		Random rand = new Random();
		int selection = rand.nextInt(max);
		SensorType sensorType = SensorType.DEFAULT;
		switch (selection)
		{
		case 0:
			sensorType = SensorType.TEMPERATURE;
			break;
		case 1:
			sensorType = SensorType.VOLUME;
			break;
		case 2:
			sensorType = SensorType.PRESSURE;
			break;
		}
		Instant sensorTimestamp = Instant.now();
		sensorValue = simulator.initialValue(sensorType);
		String sensorId = sensorType.toString() 
				+ "-" + RandomStringUtils.randomAlphabetic(3).toUpperCase();
		log.info("SensorId: " + sensorId);
		sensorData = new SensorData(sensorType, sensorTimestamp, sensorValue, sensorId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setReporter(final SensorReporter recorder) throws InterruptedException 
	{
		log.debug("setting the SensorReporter: " + recorder);
		if (recorder == null)
		{
			log.error("the SensorReporter is null");
			throw new IllegalArgumentException("SensorReporter cannot be null");
		}
		if (getStatus() != SensorStatus.INITIALIZED)
		{
			log.error("Sensor is not INITIALIZED");
			throw new IllegalStateException("Sensor is not INITIALIZED");
		}
		this.recorder = recorder;
	}	

	@Override
	public SensorStatus getStatus() throws InterruptedException {
		log.debug("Get status");
		boolean lockAcquired = lock.tryLock(1, TimeUnit.SECONDS);
		if(lockAcquired) {
			try {
				SensorStatus temp = status;
				return temp;
			} finally {
				lock.unlock();
			}
		} else {
			log.error("Could not acquire lock on status");
			throw new InterruptedException("Could not acquire lock on status...");
		}
	}

	@Override
	public void setStatus(SensorStatus status) throws InterruptedException {
		boolean lockAcquired = lock.tryLock(1, TimeUnit.SECONDS);
		if(lockAcquired) {
			try {
				this.status = status;
			} finally {
				lock.unlock();
			}
		} else {
			log.error("Could not acquire lock on status");
			throw new InterruptedException("Could not acquire lock on status...");
		}
	}

	@Override
	public void startReporting() throws InterruptedException {
		log.debug("starting to report sensor data");
		if (recorder == null)
		{
			log.error("the SensorReporter is null");
			throw new IllegalArgumentException("SensorReporter is null");
		}
		SensorStatus temp = getStatus();
		if (temp == SensorStatus.INITIALIZED || temp == SensorStatus.STOPPED)
		{
			setStatus(SensorStatus.RUNNING);
			
			runner = new Thread(worker);
			runner.setName("Sensor Worker");
			runner.start();
		}
		else
		{
			log.error("Sensor is not INITIALIZED or STOPPED");
			throw new IllegalStateException("Sensor is not INITIALIZED or STOPPED");
		}
	}

	@Override
	public void stopReporting() throws InterruptedException {
		log.debug("stopping the reporting sensor data");
		if (getStatus() != SensorStatus.RUNNING)
		{
			log.error("Sensor is not RUNNING");
			throw new IllegalStateException("Sensor is not RUNNING");
		}
		setStatus(SensorStatus.STOPPED);
		runner.interrupt();
	}

	@Override
	public void shutdown() throws InterruptedException {
		log.debug("Shutting down the sensor");
		if (getStatus() == SensorStatus.SHUTDOWN)
		{
			log.error("Sensor is already SHUTDOWN");
			throw new IllegalStateException("Sensor is already SHUTDOWN");
		}
		if (getStatus() == SensorStatus.STOPPED || getStatus() == SensorStatus.INITIALIZED)
		{
			setStatus(SensorStatus.SHUTDOWN);
		}
		else
		{
			log.error("Sensor is not INITIALIZED or STOPPED");
			throw new IllegalStateException("Sensor is not INITIALIZED or STOPPED");
		}	
	}
	
	private class Worker implements Runnable {
		@Override
		public void run() {
			log.debug("running the sensor");
			while (true) {
				try {
					if (getStatus() != SensorStatus.RUNNING) {
						log.trace("Ending sensor run");
						return;
					}
				} catch (InterruptedException e1) {
					log.warn("Thread was interrupted when checking lock");
					throw new IllegalStateException("Thread was interrupted when checking lock");
				}
				try {
					Thread.sleep(INTERVAL);
				} catch (InterruptedException e) {
					log.warn("Sleep was interrupted");
				}

				SensorType sensorType = sensorData.getSensorType();
				String sensorId = sensorData.getId();
				double currentValue = sensorData.getData();

				sensorValue = simulator.getNewValue(sensorType, currentValue);
				Instant sensorTimestamp = Instant.now();
				sensorData = new SensorData(sensorType, sensorTimestamp, sensorValue, sensorId);
				log.debug("Pushing sensor data");
				recorder.pushSensorData(sensorData);
			}
		}

	}
}
