package org.example.sensor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.config.Configurator;
import org.example.sensor.data.SensorData.SensorType;
import org.example.sensor.simulator.SensorSimulator;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.ArgumentMatchers;

public class SensorImplTest
{
	private Sensor testSensor;
	private SensorSimulator simulatorMock;
	private SensorReporter reporterMock;

	@BeforeClass
	public static void setUpBeforeClass()
	{
		Configurator.setLevel(LogManager.getLogger(SensorImpl.class).getName(), Level.TRACE);
	}

	@Before
	public void initialize() throws InterruptedException
	{
		simulatorMock = mock(SensorSimulator.class);
        when(simulatorMock.initialValue(any(SensorType.class))).thenReturn(0.0);
        when(simulatorMock.getNewValue(any(SensorType.class), ArgumentMatchers.anyDouble()))
        	.thenAnswer(i -> ((double) i.getArguments()[1]) * 1.05);
        reporterMock = mock(SensorReporter.class);
		testSensor = new SensorImpl(simulatorMock);
		testSensor.setReporter(reporterMock);
	}

	@Test(expected = IllegalArgumentException.class)
	public void nullSimulatorConstructorTest() throws InterruptedException
	{
		new SensorImpl(null);
	}

	@Test
	public void initialStatus() throws InterruptedException
	{
		SensorStatus expected = SensorStatus.INITIALIZED;
		SensorStatus actual = testSensor.getStatus();
		assertEquals(expected, actual);
	}

	@Test(expected = IllegalArgumentException.class)
	public void nullReporterTest() throws InterruptedException
	{
		testSensor.setReporter(null);
	}

	@Test(expected = IllegalStateException.class)
	public void illegalStateReporterTest() throws InterruptedException
	{
		testSensor.shutdown();
		testSensor.setReporter(reporterMock);
	}
	
	@Test
	public void runSingleThreadTest() throws InterruptedException
	{
		Sensor testSensorThread = new SensorImpl(simulatorMock);
		testSensorThread.setReporter(reporterMock);
		Thread runner1 = new Thread(() -> {
			try
			{
				testSensorThread.startReporting();
			} 
			catch (InterruptedException e)
			{
				fail(e.getMessage());
			}
		}, "runner1");
		runner1.start();
		Thread.sleep(5000);
		testSensorThread.stopReporting();
		runner1.interrupt();
		runner1.join();
		testSensor.shutdown();
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void nullReporterStartTest() throws InterruptedException
	{
		Sensor testSensorThread = new SensorImpl(simulatorMock);
	    testSensorThread.startReporting();
	}
	
	@Test(expected = IllegalStateException.class)
	public void shutdownStatusStartTest() throws InterruptedException
	{
		testSensor.setStatus(SensorStatus.SHUTDOWN);
		testSensor.startReporting();
	}
	
	@Test(expected = IllegalStateException.class)
	public void alreadyRunningStatusStartTest() throws InterruptedException
	{
		testSensor.setStatus(SensorStatus.RUNNING);
		testSensor.startReporting();
	}
	
	@Test(expected = IllegalStateException.class)
	public void runningShutdownStatusStartTest() throws InterruptedException
	{
		testSensor.setStatus(SensorStatus.RUNNING);
		testSensor.shutdown();
	}
	
	@Test(expected = IllegalStateException.class)
	public void alreadyShutdownStatusStartTest() throws InterruptedException
	{
		testSensor.setStatus(SensorStatus.SHUTDOWN);
		testSensor.shutdown();
	}
	
	@Test(expected = IllegalStateException.class)
	public void stoopedStatusStartTest() throws InterruptedException
	{
		testSensor.setStatus(SensorStatus.STOPPED);
		testSensor.stopReporting();
	}
}
