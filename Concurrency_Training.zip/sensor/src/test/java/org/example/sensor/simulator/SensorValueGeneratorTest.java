package org.example.sensor.simulator;

import static org.junit.Assert.assertTrue;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.config.Configurator;
import org.example.sensor.data.SensorData.SensorType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class SensorValueGeneratorTest
{
	private SensorValueGenerator testGenerator;

	@BeforeClass
	public static void setup()
	{
		Configurator.setLevel(LogManager.getLogger(SensorValueGenerator.class).getName(), Level.TRACE);
	}
	
	@Before
	public void initialize()
	{
		testGenerator = new SensorValueGenerator();
	}
	
	@Test
	public void testInitializePressure()
	{
		final double min = 0.0;
		final double max = 100.0;
		double value = testGenerator.initialValue(SensorType.PRESSURE);
		assertTrue(value >= min && value < max);
	}
	
	@Test
	public void testInitializeTemperature()
	{
		final double min = 0.0;
		final double max = 250.0;
		double value = testGenerator.initialValue(SensorType.TEMPERATURE);
		assertTrue(value >= min && value < max);
	}
	
	@Test
	public void testInitializeDefault()
	{
		final double min = 0.0;
		final double max = 100.0;
		double value = testGenerator.initialValue(SensorType.DEFAULT);
		assertTrue(value >= min && value < max);
	}
	
	@Test
	public void testInitializeVolume()
	{
		final double min = 0.0;
		final double max = 1500.0;
		double value = testGenerator.initialValue(SensorType.VOLUME);
		assertTrue(value >= min && value < max);
	}
	
	@Test
	public void testGetNewValuePressure()
	{
		for (int count = 0; count < 100; count++)
		{
			final double initial = 25.0;
			final double fivePercent = initial * 0.05;
			final double min = initial - fivePercent;
			final double max = initial + fivePercent;
			double value = testGenerator.getNewValue(SensorType.VOLUME, initial);
			assertTrue(value >= min && value < max);
		}
	}
	
	@Test
	public void testGetNewValueTemperature()
	{
		for (int count = 0; count < 100; count++)
		{
			final double initial = 122.0;
			final double fivePercent = initial * 0.05;
			final double min = initial - fivePercent;
			final double max = initial + fivePercent;
			double value = testGenerator.getNewValue(SensorType.TEMPERATURE, initial);
			assertTrue(value >= min && value < max);
		}
	}
	
	@Test
	public void testGetNewValueVolume()
	{
		for (int count = 0; count < 100; count++)
		{
			final double initial = 1205.0;
			final double fivePercent = initial * 0.05;
			final double min = initial - fivePercent;
			final double max = initial + fivePercent;
			double value = testGenerator.getNewValue(SensorType.VOLUME, initial);
			assertTrue(value >= min && value < max);
		}
	}

}
