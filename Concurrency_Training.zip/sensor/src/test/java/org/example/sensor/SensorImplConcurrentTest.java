package org.example.sensor;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.config.Configurator;
import org.example.sensor.data.SensorData.SensorType;
import org.example.sensor.simulator.SensorSimulator;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.ArgumentMatchers;

import com.vmlens.api.AllInterleavings;

public class SensorImplConcurrentTest 
{
	private Sensor testSensor;
	private SensorSimulator simulatorMock;
	private SensorReporter reporterMock;

	@BeforeClass
	public static void setUpBeforeClass()
	{
		Configurator.setLevel(LogManager.getLogger(SensorImpl.class).getName(), Level.TRACE);
	}

	@Before
	public void initialize() throws InterruptedException
	{
		simulatorMock = mock(SensorSimulator.class);
        when(simulatorMock.initialValue(any(SensorType.class))).thenReturn(0.0);
        when(simulatorMock.getNewValue(any(SensorType.class), ArgumentMatchers.anyDouble()))
        	.thenAnswer(i -> ((double) i.getArguments()[1]) * 1.05);
        reporterMock = mock(SensorReporter.class);
		testSensor = new SensorImpl(simulatorMock);
		testSensor.setReporter(reporterMock);
	}
	
	@Test
	@Category(ConcurrencyTest.class)
	public void runConcurrentSensorVMLens() throws InterruptedException
	{
		try (AllInterleavings testReporting =
				 AllInterleavings.builder("TestSensorReporting")
				   .showStatementsWhenSingleThreaded()
				   .maximumRuns(10)
				   .build();)
		{
			while(testReporting.hasNext())
			{
				 Sensor testSensorThread = new SensorImpl(simulatorMock);
				 testSensorThread.setReporter(reporterMock);
				 Thread runner1 = new Thread(() -> {
						try
						{
							testSensorThread.startReporting();
						}
						 catch (InterruptedException e)
						{
							fail(e.getMessage());
						}
	                }, "runner1");
				 runner1.start();
				 Thread.sleep(1000);
				 testSensorThread.stopReporting();
				 runner1.interrupt();
				 runner1.join();
			 }
			 testSensor.shutdown();
		}
	}

}
