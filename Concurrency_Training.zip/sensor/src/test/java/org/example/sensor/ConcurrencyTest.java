package org.example.sensor;

public interface ConcurrencyTest 
{
   // this is a Marker interface to categorize tests
   // this test category is used for the VMLens tests
}
