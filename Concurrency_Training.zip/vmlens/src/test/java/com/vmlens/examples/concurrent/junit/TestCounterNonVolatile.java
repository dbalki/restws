package com.vmlens.examples.concurrent.junit;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.anarsoft.vmlens.concurrent.junit.ConcurrentTestRunner;
import com.anarsoft.vmlens.concurrent.junit.ThreadCount;

@RunWith(ConcurrentTestRunner.class)
public class TestCounterNonVolatile {
	int i = 0;
	
	@ThreadCount(5)
	@Test
	public void test()  {
					i++;
	}
}
