package org.example.postcode;

import org.apache.commons.csv.CSVRecord;

public class PostCode {
	
	private String status;
	private String country;

	public PostCode(CSVRecord t) {
		// TODO Auto-generated constructor stub
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
