package org.example.postcode;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

public class PostCodeAnalyzer {

	public static void main(String[] args) {
		String[] HEADERS = { "postcode", "status", "usertype", "easting", "northing", 
				"positional_quality_indicator", "country", "latitude",
				"longitude", "postcode_no_space", "postcode_fixed_width_seven",
				"postcode_fixed_width_eight", "postcode_area", "postcode_district",
				"postcode_sector", "outcode", "incode"};

		try {
			Reader reader = new FileReader("C:\\concurrency_training\\Postcodes\\UKpostcodes.csv");
			Stream<CSVRecord> stream = CSVFormat.DEFAULT.builder()
					.setHeader(HEADERS)
					.setSkipHeaderRecord(true)
					.build()
					.parse(reader)
					.stream();
			Optional<CSVRecord> first = stream.findFirst();
			List<PostCode> collect = stream.filter(t-> t.get("status").equals("live"))
					.map(t-> new PostCode(t)).collect(Collectors.toList());
//					collect(Collectors.groupingBy();
			System.out.println("status:" + first.get().get("status").equals("'terminated'"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
