package org.example.training.docs;

/*
 * This is free and unencumbered software released into the public domain.
 * Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, 
 * either in source code form or as a compiled binary, for any purpose, commercial or 
 * non-commercial, and by any means.
 * 
 * In jurisdictions that recognize copyright laws, the author or authors of this 
 * software dedicate any and all copyright interest in the software to the public domain. 
 * We make this dedication for the benefit of the public at large and to the detriment of 
 * our heirs and successors. We intend this dedication to be an overt act of relinquishment in 
 * perpetuity of all present and future rights to this software under copyright law.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES 
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,  
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 * For more information, please refer to: https://unlicense.org/
*/

import java.util.Map;

import com.sun.javadoc.Tag;
import com.sun.tools.doclets.Taglet;     

/**
 * This is the Custom JavaDoc Annotation for an Multi-Threaded Class.
 * <br>
 * <br>
 * This annotation is designed for use at the <strong>Type</strong> (Class) level.
 * <br>
 * <br>
 * This is a <em>Block</em> annotation (Taglet).
 * <br>
 * Example: @MultiThreaded
 * <br>
 * <br>
 * This annotation outputs:
 * <pre>{@code
 * This is an <strong>Multi-Threaded Class</strong><br>
 * Multi-Threaded Classes have:
 * <ul> 
 *   <li>Local (method) scope variables are preferred</li> 
 *   <li>All variables are marked <strong>final</strong> if possible</li> 
 *   <li>Non final class scope variables are locked prior to use via:
 *     <ul>
 *       <li>Synchronization</li>
 *       <li>Explicit Locks</li>
 *       <li>Using a Concurrent Collection instance</li>
 *     </ul> 
 *   </li>
 * </ul> 
 * <br> 
 * }</pre>
 * <strong>Note:</strong> this Taglet requires <strong>tools.jar</strong> to be on the classpath,
 * tools.jar is in the <em>lib</em> folder of the JDK not the JRE.
 * 
 * 
 * @author Jonathan Earl
 * @since 1.0
 * @version 1.0
 *
 */
public class MultiThreaded 
	implements Taglet {
	
	/**
	 * The default constructor.
	 */
	public MultiThreaded() {
		super();
	}
	
	/**
     * Register this Taglet.
     * <br>
     * <br> 
     * This will register the Taglet with the JavaDoc processor.
     * Registration is required for use.
     * 
     * @param tagletMap  the map to register this tag to.
     */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void register(Map tagletMap) {
		MultiThreaded tag = new MultiThreaded();
		Taglet t = (Taglet) tagletMap.get(tag.getName());
		if (t != null) {
			tagletMap.remove(tag.getName());
		}
		tagletMap.put(tag.getName(), tag);
	}

	/**
	 * This returns the Taglet name.
	 * <br>
	 * <br>
	 * 
	 * @return the Taglet name as <strong>MultiThreaded</strong>
	 */
	@Override
	public String getName() {
		return "MultiThreaded";
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Constructor</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   Constructor JavaDocs
	 * 
	 */
	@Override
	public boolean inConstructor() {
		return false;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Field</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   Field JavaDocs
	 * 
	 */
	@Override
	public boolean inField() {
		return false;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Method</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   Method JavaDocs
	 * 
	 */
	@Override
	public boolean inMethod() {
		return false;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Overview</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   Overview JavaDocs
	 * 
	 */
	@Override
	public boolean inOverview() {
		return false;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Package</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   Package JavaDocs
	 * 
	 */
	@Override
	public boolean inPackage() {
		return false;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>Type</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>true</strong> as this Taglet is used in
	 *   Type JavaDocs
	 * 
	 */
	@Override
	public boolean inType() {
		return true;
	}

	/**
	 * This is the indicator if this Taglet can be used in the 
	 * <strong>in-line</strong> JavaDocs.
	 * <br>
	 * <br>
	 * @return returns <strong>false</strong> as this Taglet is not used in
	 *   in-line JavaDocs
	 * 
	 */
	@Override
	public boolean isInlineTag() {
		return false;
	}

	/**
	 * This returns the Custom JavaDoc (including embedded HTML) as a String.
	 * <br>
	 * <br>
	 * It returns:
	 * <pre>{@code
	 * This is an <strong>Multi-Threaded Class</strong><br>
	 * Multi-Threaded Classes have:
	 * <ul> 
	 *   <li>Local (method) scope variables are preferred</li> 
	 *   <li>All variables are marked <strong>final</strong> if possible</li> 
	 *   <li>Non final class scope variables are locked prior to use via:
	 *     <ul>
	 *       <li>Synchronization</li>
	 *       <li>Explicit Locks</li>
	 *       <li>Using a Concurrent Collection instance</li>
	 *     </ul> 
	 *   </li>
	 * </ul> 
	 * <br> 
	 * }</pre>
	 * 
	 * @param tag the specific tag (@MultiThreaded) encountered in the JavaDoc processing
	 * @return the String containing the custom HTML for this Taglet
	 * 
	 */
	@Override
	public String toString(Tag tag) {
		return buildOutput();
	}

	/**
	 * This returns the Custom JavaDoc (including embedded HTML) as a String.
	 * <br>
	 * <br>
	 * It returns:
	 * <pre>{@code
	 * This is an <strong>Multi-Threaded Class</strong><br>
	 * Multi-Threaded Classes have:
	 * <ul> 
	 *   <li>Local (method) scope variables are preferred</li> 
	 *   <li>All variables are marked <strong>final</strong> if possible</li> 
	 *   <li>Non final class scope variables are locked prior to use via:
	 *     <ul>
	 *       <li>Synchronization</li>
	 *       <li>Explicit Locks</li>
	 *       <li>Using a Concurrent Collection instance</li>
	 *     </ul> 
	 *   </li>
	 * </ul> 
	 * <br> 
	 * }</pre>
	 * 
	 * @param tagArray the specific tag (@MultiThreaded) encountered as part of 
	 *      an array of annotations during the JavaDoc processing
	 * @return the String containing the custom HTML for this Taglet
	 * 
	 */
	@Override
	public String toString(Tag[] tagArray) {
		return buildOutput();
	}
	
	private String buildOutput() {
		StringBuilder builder = new StringBuilder();
		builder.append("This is an <strong>Multi-Threaded Class</strong><br>");
		builder.append("Multi-Threaded Classes have:");
		builder.append("<ul>");
		builder.append("<li>Local (method) scope variables are preferred</li> ");
		builder.append("<li>All variables are marked <strong>final</strong> if possible</li>");
		builder.append("<li>Non final class scope variables are locked prior to use via:");
		builder.append("<ul>");
		builder.append("<li>Synchronization</li>");
		builder.append("<li>Explicit Locks</li>");
		builder.append("<li>Using a Concurrent Collection instance</li>");
		builder.append("</ul>");
		builder.append("</li>");
		builder.append("</ul>");
		builder.append("<br>");
		
		return builder.toString();
	}
}
