package org.example.master.sensor.manager;


import org.junit.Before;
import org.junit.Test;

public class MasterSensorManagerImplTest {
	
	private MasterSensorManagerImpl masterSensorManager;

	@Before
	public void setUp() throws Exception {
		masterSensorManager = new MasterSensorManagerImpl(3);
	}

	@Test
	public void testMasterSensorManagerWith3Controllers() throws InterruptedException {
		Thread thread = new Thread(masterSensorManager);
		thread.start();
		Thread.sleep(60000);
		thread.join();
	}

}
