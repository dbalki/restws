/**
 * 
 */
package org.example.master.sensor.manager;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Phaser;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.sensor.controller.SensorController;
import org.example.sensor.controller.SensorControllerImpl;
import org.example.sensor.data.SensorSummary;

/**
 * @author Administrator
 *
 */
public class MasterSensorManagerImpl implements MasterSensorManager, Runnable {
	
	private int numberOfSensorControllers;
	private Queue<SensorSummary> queue = new ConcurrentLinkedQueue<>();
	private static final Logger log = LogManager.getLogger();
	
	public MasterSensorManagerImpl(int numberOfSensorControllers) 
	{
		this.numberOfSensorControllers = numberOfSensorControllers;
	}
	

	@Override
	public void run() {
		log.debug("Master Sensor manager starts...");
		Phaser phaser = new Phaser();
		log.debug("Create and start the sensor controllers");
		createSensorControllers(numberOfSensorControllers, phaser);
		log.debug("Write report");
		writeReport(queue);
		log.debug("Master Sensor manager ends...");
	}

	private void writeReport(Queue<SensorSummary> queue) {
		for (SensorSummary sensorSummary : queue) {
			log.info("Summary: {}", sensorSummary);
		}
	}

	class SensorControllerTask implements Runnable {

		private Phaser phaser;
		private Queue<SensorSummary> queue;
		private int controllerNum;
		
		public SensorControllerTask(Queue<SensorSummary> queue, Phaser phaser, int controllerNum) {
			this.queue = queue;
			this.phaser = phaser;
			this.controllerNum = controllerNum;
		}

		@Override
		public void run() {
			// Phase 0
			// wait for the go command
			phaser.arriveAndAwaitAdvance();
			
			log.debug("Phase 1 for sensor controller {}", controllerNum);
			SensorController sensorController = new SensorControllerImpl();
			int numberOfSensors = ThreadLocalRandom.current().nextInt(10) + 1;
			sensorController.createSensors(numberOfSensors);
			log.debug("Created and started {} sensors", numberOfSensors);
			phaser.arriveAndAwaitAdvance();
			
			log.debug("Phase 2 wait for 30 seconds");
			// Wait for 30 seconds
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
			phaser.arriveAndAwaitAdvance();
			
			log.debug("Phase 3 Stop sensors");
			sensorController.stopSensors();
			log.debug("Stopped {} sensors", numberOfSensors);
			phaser.arriveAndAwaitAdvance();
			
			log.debug("Phase 4 for sensor controller{}", controllerNum);
			log.debug("Pull summary");
			queue.add(sensorController.pullSummaries());
			phaser.arriveAndAwaitAdvance();
			
			log.debug("Phase 5 for sensor controller{}", controllerNum);
			sensorController.shutdownSensors();
			phaser.arriveAndDeregister();
			log.debug("Sensor controller {} ended", controllerNum);
		}
		
	}

	@Override
	public void createSensorControllers(int numberOfSensorControllers, Phaser phaser) {
		log.debug("Creating {} sensor controllers", numberOfSensorControllers);
		ExecutorService threadPool = Executors.newFixedThreadPool(numberOfSensorControllers);
		for (int i = 0; i < numberOfSensorControllers; i++) {
			SensorControllerTask task = new SensorControllerTask(queue, phaser, i);
			log.debug("Created sensor controllers {}", i);
			phaser.register();
			threadPool.execute(task);
		}
		threadPool.shutdown();
	}

}
