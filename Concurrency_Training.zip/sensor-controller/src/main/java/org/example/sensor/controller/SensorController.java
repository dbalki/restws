package org.example.sensor.controller;

import org.example.sensor.data.SensorSummary;

/*
 * This is free and unencumbered software released into the public domain.
 * Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, 
 * either in source code form or as a compiled binary, for any purpose, commercial or 
 * non-commercial, and by any means.
 * 
 * In jurisdictions that recognize copyright laws, the author or authors of this 
 * software dedicate any and all copyright interest in the software to the public domain. 
 * We make this dedication for the benefit of the public at large and to the detriment of 
 * our heirs and successors. We intend this dedication to be an overt act of relinquishment in 
 * perpetuity of all present and future rights to this software under copyright law.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES 
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,  
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 * For more information, please refer to: https://unlicense.org/
*/

/**
 * This is the main SensorController interface.
 * <br>
 * <br>
 * This interface will allow a MasterSensorManager to control the activity of
 * a SensorController.<br>
 * <br>
 * 
 * @author Jonathan Earl
 * @since 1.0
 * @version 1.0
 *
 */
public interface SensorController
{
	/**
	 * This will create a set of Sensors.
	 * <br>
	 * <br>
	 * This will also create a matching set of SingleSensorManager object 
	 * to manage these sensors.
	 * 
	 * @param numberOfSensors to create
	 */
	void createSensors(int numberOfSensors);
	
	/**
	 * This will start the set of Sensors.
	 * <br>
	 * <br>
	 * 
	 */
	void startSensors();
	
	/**
	 * This will stop the set of Sensors.
	 * <br>
	 * <br>
	 * 
	 */
	void stopSensors();
	
	/**
	 * This will pull the current SensorSummary data for a specific Sensor.
	 * <br>
	 * <br>
	 * @param sensorNumber to pull the SensorSummary from
	 * @return the SensorSummary for this Sensor
	 */
	SensorSummary pullSummary(int sensorNumber);
	
	/**
	 * This will pull the current SensorSummary data for all Sensors managed by this
	 * SensorController.
	 * <br>
	 * <br>
	 * @return the SensorSummary for all Sensors
	 */
	SensorSummary pullSummaries();
	
	/**
	 * This will shutdown all the Sensors managed by this SensorController.
	 * <br>
	 * <br>
	 * This will also terminate all the SingleSensorManager objects for this SensorController.
	 */
	void shutdownSensors();
}
