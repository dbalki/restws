/**
 * 
 */
package org.example.sensor.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.sensor.Sensor;
import org.example.sensor.SensorImpl;
import org.example.sensor.data.SensorData;
import org.example.sensor.data.SensorSummary;
import org.example.sensor.simulator.SensorSimulator;
import org.example.sensor.simulator.SensorValueGenerator;

/**
 * Controls a group of sensors. 
 * 
 * @author Administrator
 *
 */
public class SensorControllerImpl implements SensorController 
{
	private static final Logger log = LogManager.getLogger();
	private List<SingleSensorManager> sensorManagers = new ArrayList<>();
	private ExecutorService threadPoolExecutor;

	/**
	 * Constructor.
	 */
	public SensorControllerImpl() 
	{ }

	@Override
	public void createSensors(int numberOfSensors) 
	{
		log.debug("Create {} sensors", numberOfSensors);
		if (numberOfSensors < 1)
		{
			log.error("the numberOfSensors is invalid");
			throw new IllegalArgumentException("the numberOfSensors is invalid");
		}
		threadPoolExecutor = Executors.newFixedThreadPool(numberOfSensors);
		for (int i = 0; i < numberOfSensors; i++) 
		{
			SensorSimulator simulator = new SensorValueGenerator();
			try 
			{
				log.trace("Creating a SingleSensorManger instance");
				Sensor sensor = new SensorImpl(simulator);
				SingleSensorManagerImpl manager = new SingleSensorManagerImpl();
				sensor.setReporter(manager);
				manager.setSensor(sensor);
				sensorManagers.add(manager);
				threadPoolExecutor.execute(manager);
			} catch (InterruptedException e) 
			{
				log.error(e);
				throw new RuntimeException("Can not create sensors");
			}
		}

	}

	@Override
	public SensorSummary pullSummary(int sensorNumber) 
	{
		if (sensorNumber > sensorManagers.size())
		{
			log.error("the numberOfSensors is invalid");
			throw new IllegalArgumentException("the numberOfSensors is invalid");
		}
		log.debug("Pull summary for sensor number {}", sensorNumber);
		SingleSensorManager singleSensorManager = sensorManagers.get(sensorNumber);
		List<SensorData> sensorData = singleSensorManager.getSensorData();
		SensorSummary summary = new SensorSummary();
		summary.setNumberOfSensors(1);
		summary.addSensorData(sensorData.get(sensorData.size() - 1));
		return summary;
	}
	
	@Override
	public SensorSummary pullSummaries()
	{
		log.debug("Pulling all the SensorSummaries");
		SensorSummary summary = new SensorSummary();
		summary.setNumberOfSensors(sensorManagers.size());
		for (SingleSensorManager singleSensorManager: sensorManagers)
		{
			log.trace("pulling the latest SensorData");
			List<SensorData> data = singleSensorManager.getSensorData();
			summary.addSensorData(data.get(data.size() - 1));
		}
		return summary;
	}
	
	@Override
	public void shutdownSensors() {
		log.debug("Shutdown sensors");
		for (SingleSensorManager sensorManager : sensorManagers) 
		{
			sensorManager.stopSensor();
		}
		sensorManagers.clear();
		threadPoolExecutor.shutdown();
	}

	@Override
	public void startSensors() {
		log.debug("Start sensors");
		for (SingleSensorManager sensorManager : sensorManagers) 
		{
			sensorManager.startSensor();
		}
	}

	@Override
	public void stopSensors() {
		log.debug("Stop sensors");
		for (SingleSensorManager sensorManager : sensorManagers) 
		{
			sensorManager.stopSensor();
		}
	}

}
