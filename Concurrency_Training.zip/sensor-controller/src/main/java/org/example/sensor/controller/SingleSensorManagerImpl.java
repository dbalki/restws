/**
 * 
 */
package org.example.sensor.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.sensor.Sensor;
import org.example.sensor.SensorReporter;
import org.example.sensor.SensorStatus;
import org.example.sensor.data.SensorData;

/**
 * Manages a single sensor.
 * @author Administrator
 *
 */
public class SingleSensorManagerImpl implements SingleSensorManager, SensorReporter, Runnable  
{
	private Sensor sensor;
	private List<SensorData> sensorData = new ArrayList<SensorData>();
	private volatile Logger log = LogManager.getLogger();

	@Override
	public void setSensor(Sensor sensor) 
	{
		if (sensor == null) 
		{
			log.error("Sensor is null");
			throw new IllegalArgumentException("Sensor is null");
		}
		this.sensor = sensor;
		log.debug("sensor is set");
	}

	@Override
	public void startSensor() 
	{
		if (sensor == null) 
		{
			log.error("sensor is not set");
			throw new IllegalArgumentException("Sensor is not set");
		}
		log.debug("start sensor...");
		try {
			if (sensor.getStatus() != SensorStatus.INITIALIZED || sensor.getStatus() == SensorStatus.STOPPED) 
			{
				log.error("Sensor is not initialized or stopped");
				throw new IllegalStateException("Sensor is not initialized or stopped");
			}
			log.debug("start reporting...");
			sensor.startReporting();
			log.debug("start reporting");
		} catch (InterruptedException e) 
		{
			log.error("Sensor interrupted");
		}

	}

	@Override
	public void stopSensor() 
	{
		if (sensor == null) 
		{
			log.error("sensor is not set");
			throw new IllegalArgumentException("Sensor is not set");
		}
		log.debug("stopping sensor...");
		try 
		{
			if (sensor.getStatus() != SensorStatus.RUNNING) 
			{
				log.error("Sensor is not running");
				throw new IllegalStateException("Sensor is not running");
			}
			sensor.stopReporting();
			log.debug("sensor stopped...");
		} catch (InterruptedException e) 
		{
			log.error("Sensor interrupted");
		}
	}

	@Override
	public List<SensorData> getSensorData() 
	{
		if (sensor == null) 
		{
			log.error("sensor is not set");
			throw new IllegalArgumentException("Sensor is not set");
		}
		log.debug("Get sensor data...");
		return sensorData;
	}

	@Override
	public SensorStatus getSensorStatus() 
	{
		if (sensor == null) 
		{
			log.error("sensor is not set");
			throw new IllegalArgumentException("Sensor is not set");
		}
		log.debug("Get sensor status...");
		try 
		{
			return sensor.getStatus();
		} catch (InterruptedException e) 
		{
			log.error("Sensor interrupted");
			throw new IllegalStateException("getting the Sensor status was Interrupted");
		}
	}

	@Override
	public void pushSensorData(SensorData data) 
	{
		log.debug("adding to the collection of SensorData");
		sensorData.add(data);
	}

	@Override
	public void run() 
	{
		log.debug("start run...");
		startSensor();
	}

}
