package org.example.sensor.controller;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SingleSensorMangerTest
{
	private SingleSensorManager testSingleSensorManager;

	@BeforeClass
	public static void setUpBeforeClass()
	{
		Configurator.setLevel(LogManager.getLogger(SingleSensorManager.class).getName(), Level.TRACE);
	}

	@Before
	public void initialize() throws InterruptedException
	{
		testSingleSensorManager = new SingleSensorManagerImpl();
	}

	@Test(expected = IllegalArgumentException.class)
	public void nullSimulatorConstructorTest()
	{
		testSingleSensorManager.setSensor(null);
	}
	
	@Test 
	public void nullSensorDuringRun() throws Exception 
	{
		SingleSensorManagerImpl testInstance = new SingleSensorManagerImpl();
		ExecutorService es = Executors.newSingleThreadExecutor();
		Future<?> future = es.submit(testInstance);
		try
		{
			future.get(); // This will rethrow Exceptions and Errors as ExecutionException
		} 
		catch (ExecutionException e)
		{
			assertTrue(e.getCause() instanceof IllegalArgumentException);
		}
	}

}
