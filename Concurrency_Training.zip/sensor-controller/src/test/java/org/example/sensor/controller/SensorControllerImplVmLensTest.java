package org.example.sensor.controller;

import org.junit.Test;

import com.vmlens.api.AllInterleavings;

public class SensorControllerImplVmLensTest {

	@Test
	public void test() throws InterruptedException {
		try (AllInterleavings testReporting =
				 AllInterleavings.builder("TestControllerImpl.vmlens")
				   .showStatementsWhenSingleThreaded()
				   .maximumRuns(10)
				   .build();)
		{
			while (testReporting.hasNext()) 
			{
				SensorController sensorController = new SensorControllerImpl();
				Thread runner1 = new Thread(() -> 
				{
					sensorController.createSensors(2);
					sensorController.stopSensors();
				}, "runner1");
//				Thread runner2 = new Thread(() -> 
//				{
//					SensorController sensorController = new SensorControllerImpl();
//					sensorController.createSensors(2);
//					sensorController.stopSensors();
//				}, "runner2");
				runner1.start();
//				runner2.start();
//				Thread.sleep(1000);
				runner1.join();
//				runner2.join();
			}
		}
	}

}
