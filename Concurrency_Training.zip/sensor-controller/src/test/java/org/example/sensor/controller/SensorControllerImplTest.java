package org.example.sensor.controller;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SensorControllerImplTest {
	
	@BeforeClass
	public static void setUpBeforeClass()
	{
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testSensorController() {
		SensorController sensorController = new SensorControllerImpl();
		sensorController.createSensors(2);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		sensorController.stopSensors();
	}

}
